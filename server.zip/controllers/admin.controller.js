const asyncHandler = require("express-async-handler")

exports.getAllProducts = asyncHandler(async () => {
    res.json({ message: "product Fetch Success" })
})
exports.addProduct = asyncHandler(async () => {
    res.json({ message: "product add Success" })
})
exports.updateProduct = asyncHandler(async () => {
    res.json({ message: "product update Success" })
})
exports.deleteProduct = asyncHandler(async () => {
    res.json({ message: "product delete Success" })
})


exports.deactivateProduct = asyncHandler(async () => {
    res.json({ message: "product Deactivate Success" })
})
exports.activateProduct = asyncHandler(async () => {
    res.json({ message: "product activate Success" })
})
exports.getProductDetails = asyncHandler(async () => {
    res.json({ message: "product  Detail Fetch Success" })
})

//orders
exports.getAllOrders = asyncHandler(async () => {
    res.json({ message: "ordrs  Fetch update" })
})
exports.getOrderDetail = asyncHandler(async () => {
    res.json({ message: "ordrs  order Details " })
})
exports.cancelOrder = asyncHandler(async () => {
    res.json({ message: "ordrs  cancel success" })
})
exports.updateOrderStatus = asyncHandler(async () => {
    res.json({ message: "ordrs  update success " })
})

// user
exports.getAllUser = asyncHandler(async () => {
    res.json({ message: "user fetch  Success" })
})
exports.getUserDetails = asyncHandler(async () => {
    res.json({ message: "user Detail fetch  Success" })
})
exports.blockUser = asyncHandler(async () => {
    res.json({ message: "user Block Success" })
})
exports.unblockUser = asyncHandler(async () => {
    res.json({ message: "user un-Block  Success" })
})
exports.getUserOrders = asyncHandler(async () => {
    res.json({ message: "user Order  fetch  Success" })
})


